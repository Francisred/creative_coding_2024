import App from "./js/App.js";

const monApp = new App();

// Your code here
monApp.createCanvas(window.innerWidth, window.innerHeight);

monApp.createGrid();
document.body.style.backgroundColor = "black";
